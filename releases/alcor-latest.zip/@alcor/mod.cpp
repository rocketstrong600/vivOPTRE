name = "vehicle in vehicle Pelican";
description = "makes pelicans use arma 3 apex vehicle in vehicle";
tooltip = "vehicle in vehicle";
tooltipOwned = "ALCORLABS";
overview = "makes pelicans use vehicle in vehicle";
author = "Ethan Johnston";
